<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>Php Partie 3 - ex 1 - Les boucles</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h1>Les boucles</h1>
    <?php
    //Elle prend en paramètre l'initialisation de la valeur de la variable
    $var=0;
    // On utilise la boucle while
    while ($var<= 10) { ?>
      <p class="result"><?= $var ?></p>
      <?php
      //puis sa valeur à atteindre et enfin le mode d'incrémentation
      $var++;
    }
     ?>
  </body>
</html>
