<?php
// on initialise deux variables
$firstvar = 0;
//pour attribuer au hasard une valeur entre 1 et 100
//on utilise la fonction rand (min,max)
$secondvar = rand(1,100);
 ?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>Php Partie 3 - ex 2 - Les boucles</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <h1>Les boucles - exercice 2</h1>
    <p class="firstvar">La valeur de la firstvar : <?= $firstvar ?></p>
    <p class="secondvar">La valeur de la secondvar : <?= $secondvar ?></p>
    <?php
    // On va créer une boucle qui vérifiera que firstvar n'est pas supérieur à 20
    // Comme le nombre d'itération n'est pas déterminé on va utiliser la boucle while
    while ($firstvar <= 20) {
      //On multiplie firstvar par secondvar et on l'affiche
      ?><p class="result"><?= $firstvar * $secondvar ?></p>
      <?php
      //on incrémente firstvar
      $firstvar++ ;
    }
     ?>
  </body>
</html>
